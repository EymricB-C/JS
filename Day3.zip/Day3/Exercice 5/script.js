const secondArm = document.querySelector('#second');
const minsArm = document.querySelector('#minute');
const hourArm = document.querySelector('#hour');

function clock() {
    let temp = new Date();

    let seconds = temp.getSeconds();
    let secondsRotate = seconds * 6;
    secondArm.style.transform = `rotate(${secondsRotate}deg)`;

    let mins = temp.getMinutes();
    let minsRotate = mins * 6;
    minsArm.style.transform = `rotate(${minsRotate}deg)`;

    let hour = temp.getHours();
    let hourRotate = (hour + 1) * 30;
    hourArm.style.transform = `rotate(${hourRotate}deg)`;
}

setInterval(clock, 1000);