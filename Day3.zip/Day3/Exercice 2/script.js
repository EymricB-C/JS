let main = document.createElement('div');
main.classList.add('main');
document.body.prepend(main);

const container = document.querySelector('div');

let uul = document.createElement('ul');
uul.classList.add('liste');
container.appendChild(uul);

const liste = document.querySelector('ul');
let l1 = document.createElement('li');
liste.appendChild(l1);
let l2 = document.createElement('li');
liste.appendChild(l2);

const liste2 = document.querySelectorAll('li');

for(i=0; i<2; i++){
    let ass = `<a href='lien${i+1}.php' class='lien'>page 1</a>`;
    liste2[i].innerHTML += ass;
}