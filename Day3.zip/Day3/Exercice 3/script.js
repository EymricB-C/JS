let otpCodeInputs = document.getElementsByClassName('inside');
let otpSubmitButton = document.getElementById('submit');

for (let otpCodeInput of otpCodeInputs) {
    otpCodeInput.addEventListener('input', (evt) => {
        let valid = validateNumber(evt, otpCodeInput);
        if(valid){
            submit();
            focusNextInput(evt, otpCodeInput);
        }
})}

function validateNumber(evt, input) {
    let value = Number(evt.data);
    if (isNaN(value)){
        alert('Ce n\'est pas un nombre !');
        input.value = null;
        return false;
    }
    return true
}

function focusNextInput(evt, currentInput){
    let currentInputId = currentInput.attributes.id.value;
    let currentInputIndex = currentInputId[currentInputId.length - 1];
    let nextInput = document.getElementById(`${Number(currentInputIndex) + 1}`)
    if (nextInput){
        nextInput.focus();
    }else {
        submit();
    }
}

function submit() {
    let canSubmit = true;

    for(let otpCodeInput of otpCodeInputs) {
        if (!otpCodeInput.value){
            canSubmit = false;
            break;
        }
    }

    if(canSubmit){
        setTimeout(()=>alert('feff'), 10)
    }
}