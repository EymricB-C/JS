//1
const p1 = document.getElementById('1');
const p2 = document.getElementById('2');
const p3 = document.getElementById('3');
const p4 = document.getElementById('4');
const p5 = document.getElementById('5');
const p6 = document.getElementById('6');

p3.insertAdjacentElement('afterend', p1);
p2.insertAdjacentElement('beforebegin', p4);
p6.insertAdjacentElement('afterbegin', p5);